<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fashion_daily
 */

get_header(); ?>

<div id="content" <?php echo fashion_daily_get_container_classes( 'site-content' ); ?>><?php

	do_action( 'fashion_daily-theme/site/site-content-before', 'archive' ); ?>

	<div <?php fashion_daily_content_class() ?>>

		<div class="row">

			<?php do_action( 'fashion_daily-theme/site/primary-before', 'archive' ); ?>

			<div id="primary" <?php fashion_daily_primary_content_class(); ?>>

				<?php do_action( 'fashion_daily-theme/site/main-before', 'archive' ); ?>

				<main id="main" class="site-main">
					<div class="card-wrapper"><?php
						
						get_template_part( 'template-parts/breadcrumbs' );

						echo '<header class="page-header">';
							
							echo the_archive_title( '<h1 class="page-title">', '</h1>' );
							echo the_archive_description( '<div class="archive-description">', '</div>' );

						echo '</header><!-- .page-header -->';

						if ( have_posts() ) :

							fashion_daily_theme()->do_location( 'archive', 'template-parts/posts-loop' );

						else :

							get_template_part( 'template-parts/content', 'none' );

						endif;

					?></div>
				</main><!-- #main -->

				<?php do_action( 'fashion_daily-theme/site/main-after', 'archive' ); ?>

			</div><!-- #primary -->

			<?php do_action( 'fashion_daily-theme/site/primary-after', 'archive' ); ?>

			<?php get_sidebar(); // Loads the sidebar.php template.  ?>
		</div>
	</div>

	<?php do_action( 'fashion_daily-theme/site/site-content-after', 'archive' ); ?>

</div><!-- #content -->

<?php get_footer();
