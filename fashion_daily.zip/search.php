<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Fashion_daily
 */

get_header(); ?>

<div id="content" <?php echo fashion_daily_get_container_classes( 'site-content' ); ?>><?php

	do_action( 'fashion_daily-theme/site/site-content-before', 'search' ); ?>

	<div <?php fashion_daily_content_class() ?>>
		
		<div class="row">

			<?php do_action( 'fashion_daily-theme/site/primary-before', 'search' ); ?>

			<div id="primary" <?php fashion_daily_primary_content_class(); ?>>

				<?php do_action( 'fashion_daily-theme/site/main-before', 'search' ); ?>

				<main id="main" class="site-main">
					<div class="card-wrapper"><?php
					
						get_template_part( 'template-parts/breadcrumbs' );

						if ( have_posts() ) :

							fashion_daily_theme()->do_location( 'archive', 'template-parts/search-loop' );

						else :

							get_template_part( 'template-parts/content', 'none' );

						endif;
					?></div>
				</main><!-- #main -->

				<?php do_action( 'fashion_daily-theme/site/main-after', 'search' ); ?>

			</div><!-- #primary -->

			<?php do_action( 'fashion_daily-theme/site/primary-after', 'search' ); ?>

			<?php
				get_sidebar(); // Loads the sidebar.php template.
			?>
		</div>
	</div>

	<?php do_action( 'fashion_daily-theme/site/site-content-after', 'search' ); ?>

</div><!-- #content -->

<?php get_footer();
