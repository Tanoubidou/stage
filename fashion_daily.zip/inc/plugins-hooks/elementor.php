<?php
/**
 * Elementor hooks.
 *
 * @package Fashion_daily
 */