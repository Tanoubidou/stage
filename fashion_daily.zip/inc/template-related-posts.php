<?php
/**
 * Related Posts Template Functions.
 *
 * @package Fashion_daily
 */

if ( ! class_exists( 'Fashion_daily_Related_Posts' ) ) {

	class Fashion_daily_Related_Posts {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * Settings properties.
		 *
		 * @var array
		 */
		public $settings = array();

		/**
		 * Constructor for the class.
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			if ( ! is_singular( 'post' ) ) {
				return;
			}

			$this->set_settings();

			if ( ! $this->get_setting( 'visible' ) ) {
				return;
			}

			$this->build_html();
		}

		/**
		 * Set settings from customize options.
		 */
		public function set_settings() {

			$settings = apply_filters( 'fashion_daily_related_post_settings_map', array(
				'visible' 				=> 'related_posts_visible',
				'block_title' 			=> 'related_posts_block_title',
				'query_type' 			=> 'related_posts_query_type',
				'posts_count' 			=> 'related_posts_count',
				'layout_columns' 		=> 'related_posts_grid',
				'title_visible' 		=> 'related_posts_title',
				'image_visible' 		=> 'related_posts_image',
				'content_type' 			=> 'related_posts_excerpt',
				'content_length' 		=> 'related_posts_excerpt_words_count',
				'author_visible' 		=> 'related_posts_author',
				'date_visible' 			=> 'related_posts_publish_date',
				'comment_visible' 		=> 'related_posts_comment_count',
			) );

			foreach ( $settings as $setting_key => $setting_value ) {
				$this->settings[ $setting_key ] = fashion_daily_theme()->customizer->get_value( $setting_value );
			}
		}

		/**
		 * Get setting value.
		 *
		 * @param string $setting Setting name.
		 *
		 * @return mixed
		 */
		public function get_setting( $setting = null ) {

			if ( ! isset( $this->settings[ $setting ] ) ) {
				return null;
			}

			return $this->settings[ $setting ];
		}

		/**
		 * Build the related posts html.
		 */
		public function build_html() {
			$wrapper_view_dir = locate_template( 'template-parts/related-posts/wrapper.php' );

			if ( ! $wrapper_view_dir ) {
				return;
			}

			$block_title_format = apply_filters( 'fashion_daily_related_posts_block_title_format', '<h4 class="related-posts__title">%s</h4>' );
			$block_title        = ( $this->get_setting( 'block_title' ) ) ? sprintf( $block_title_format, $this->get_setting( 'block_title' ) ) : '';

			global $post;

			$post_obj   = get_post( $post );
			$query_type = $this->get_setting( 'query_type' );
			$terms      = get_the_terms( $post_obj, $query_type );

			// Get related posts html
			$related_posts = '';

			if ( $terms ) {
				$related_post_terms = wp_list_pluck( $terms, 'term_id' );
				$related_sort_key   = ( 'category' === $query_type ) ? 'category__in' : 'tag__in';

				$related_posts = $this->get_query_items( array( $related_sort_key => $related_post_terms ), 'related-query' );
			}

			// Get author posts html
			$author_posts = $this->get_query_items( array( 'author' => $post->post_author ), 'author-query' );

			if ( ! $related_posts && ! $author_posts ) {
				return;
			}

			$start_tab = $related_posts ? 'related-query' : 'author-query';

			if ( ! $related_posts ) {
				$related_posts = sprintf( '<p class="no-posts col-xs-12">%1$s</p>', esc_html__( 'No related posts.', 'fashion_daily' ) );
			}

			if ( ! $author_posts ) {
				$author_posts = sprintf( '<p class="no-posts col-xs-12">%1$s</p>', esc_html__( 'No more post this author.', 'fashion_daily' ) );
			}

			include $wrapper_view_dir;
		}

		/**
		 * Get query items.
		 *
		 * @param array $query_args  Query arguments.
		 * @param null  $extra_class Extra css class.
		 *
		 * @return bool|string
		 */
		public function get_query_items( $query_args = array(), $extra_class = null ) {

			global $post;

			$default_query_args = array(
				'post_type'    => 'post',
				'numberposts'  => (int) $this->get_setting( 'posts_count' ),
				'post__not_in' => array( $post->ID ),
			);

			$query_args = wp_parse_args( $query_args, $default_query_args );

			$posts = get_posts( $query_args );

			if ( ! $posts ) {
				return false;
			}

			$item_view_dir = locate_template( 'template-parts/related-posts/item.php' );

			if ( ! $item_view_dir ) {
				return false;
			}

			$content_visible = ( 0 === $this->get_setting( 'content_length' ) || false == $this->get_setting( 'content_type' ) ) ? false : true;
			$grid_columns    = (int) 12 / $this->get_setting( 'layout_columns' );

			ob_start();

			foreach ( $posts as $post ) {
				setup_postdata( $post );

				$related_classes = array( 'related-post', 'col-xs-12', 'col-md-6' );
				$related_classes[] = 'col-xl-' . $grid_columns;

				if ( $extra_class ) {
					$related_classes[] = $extra_class;
				}

				$related_classes[] = ( has_post_thumbnail() && $this->get_setting('image_visible') ) ? 'has-thumb' : 'no-thumb';

				$related_classes = join( ' ', $related_classes );

				include $item_view_dir;

			} // End foreach().

			wp_reset_postdata();

			return ob_get_clean();
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
} // End if().

/**
 * Returns instance of Fashion_daily_Related_Posts class.
 *
 * @since  1.0.0
 * @return object
 */
function fashion_daily_related_posts() {
	return Fashion_daily_Related_Posts::get_instance();
}
