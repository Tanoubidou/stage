# Fashion_daily
Fashion_daily - WordPress theme. Built with love and care by Zemez.

## Changelog

### 1.0.0
- SYS: init