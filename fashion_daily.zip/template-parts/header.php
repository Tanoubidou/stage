<?php
/**
 * The template for displaying the header
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Fashion_daily
 */

do_action( 'fashion_daily_before_header_bar' );

do_action( 'fashion_daily_header_bar' );

do_action( 'fashion_daily_after_header_bar' );
